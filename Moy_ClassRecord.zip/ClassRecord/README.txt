{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf600
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 README\
\
Jennifer Moy\
ClassRecord\
\
Resources:\
hashmap an ArrayList:\
https://stackoverflow.com/questions/19541582/storing-and-retrieving-arraylist-values-from-hashmap\
\
creating a singleton class:\
https://stackoverflow.com/questions/40152454/arraylist-initialized-accessed-using-singleton-class\
\
linking the hash map ArrayLists (key:className, value:studentList):\
https://stackoverflow.com/questions/16730364/add-arraylist-to-another-arraylist-in-java}