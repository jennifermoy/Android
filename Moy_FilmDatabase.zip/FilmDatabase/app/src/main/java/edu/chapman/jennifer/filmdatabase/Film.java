package edu.chapman.jennifer.filmdatabase;

public class Film {

    String code = null;
    String name = null;
    String releaseDate = null;
    String fileName = null;

    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getReleaseDate() {
        return releaseDate;
    }
    public void setReleaseDate(String continent) {
        this.releaseDate = continent;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String region) {
        this.fileName = region;
    }
}
