package edu.chapman.jennifer.loginlayout;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SuccessfulLogin extends Activity {

    static String TAG = "SuccessfulLogin";

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginscreen2);
        Log.i(TAG, "onCreate");

        TextView txtName = findViewById(R.id.txtName);
        Button bnClose = findViewById(R.id.bnClose);

        Intent i = getIntent();

        String name = i.getStringExtra("name");

        txtName.setText(name);

        bnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "onPause");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy");
    }
}
